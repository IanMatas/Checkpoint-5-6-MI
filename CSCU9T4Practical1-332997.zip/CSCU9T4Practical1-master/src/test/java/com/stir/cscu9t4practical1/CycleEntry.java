package com.stir.cscu9t4practical1;

public class CycleEntry extends Entry {

  private final String terrain;
  private final String tempo;

  /**
   * Constructs a new CycleEntry with the provided details.
   * @param n The name of the entry.
   * @param d The day of the entry.
   * @param m The month of the entry.
   * @param y The year of the entry.
   * @param h The hour of the entry.
   * @param min The minute of the entry.
   * @param s The second of the entry.
   * @param km The distance covered in the entry.
   * @param terrain The terrain of the entry.
   * @param tempo The tempo of the entry.
   */
  public CycleEntry(String n, int d, int m, int y, int h, int min, int s, float km, String terrain, String tempo) {
    super(n, d, m, y, h, min, s, km);
    this.terrain = terrain;
    this.tempo = tempo;
  }

  /**
   * Retrieves the terrain of the cycle entry.
   * @return The terrain of the cycle entry.
   */
  public String getTerrain() {
    return terrain;
  }
  /**
   * Retrieves the tempo of the cycle entry.
   * @return The tempo of the cycle entry.
   */
  public String getTempo() {
    return tempo;
  }
  /**
   * Retrieves a string representation of the cycle entry.
   * @return A string containing the details of the cycle entry.
   */
  @Override
  public String getEntry() {
    return getName() + " cycled " + getDistance() + " km in " + getHour() + ":" + getMin() + ":" + getSec() +
      " on " + getDay() + "/" + getMonth() + "/" + getYear() + " on " + terrain + " at " + tempo + " tempo\n";
  }
}