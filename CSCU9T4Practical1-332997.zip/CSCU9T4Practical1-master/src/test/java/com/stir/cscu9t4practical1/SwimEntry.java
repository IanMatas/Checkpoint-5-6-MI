package com.stir.cscu9t4practical1;

/**
 * Represents a swimming training entry.
 */
public class SwimEntry extends Entry {

    private String where; 

    /**
     * Constructs a new SwimEntry with the provided details.
     * @param n The name of the entry.
     * @param d The day of the entry.
     * @param m The month of the entry.
     * @param y The year of the entry.
     * @param h The hour of the entry.
     * @param min The minute of the entry.
     * @param s The second of the entry.
     * @param km The distance covered in the entry.
     * @param where The location of the swimming session.
     */
    public SwimEntry(String n, int d, int m, int y, int h, int min, int s, float km, String where) {
        super(n, d, m, y, h, min, s, km);
        this.where = where;
    }

    /**
     * Retrieves the location of the swimming session.
     * @return The location of the swimming session.
     */
    public String getWhere() {
        return where;
    }

    /**
     * Generates a string representation of the swim entry.
     * @return A string containing the details of the swim entry.
     */
    @Override
    public String getEntry() {
        return getName() + " swam " + getDistance() + " km in " + getHour() + ":" + getMin() + ":" + getSec()
                + " on " + getDay() + "/" + getMonth() + "/" + getYear() + " at " + where + "\n";
    }
}
