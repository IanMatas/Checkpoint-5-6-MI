package com.stir.cscu9t4practical1;

/**
 * Represents a sprint training entry.
 */
public class SprintEntry extends Entry {

    private final int repetitions; 
    private final int recovery;    

    /**
     * Constructs a new SprintEntry with the provided details.
     * @param n The name of the entry.
     * @param d The day of the entry.
     * @param m The month of the entry.
     * @param y The year of the entry.
     * @param h The hour of the entry.
     * @param min The minute of the entry.
     * @param s The second of the entry.
     * @param km The distance covered in the entry.
     * @param repetitions The number of repetitions.
     * @param recovery The duration of recovery.
     */
    public SprintEntry(String n, int d, int m, int y, int h, int min, int s, float km, int repetitions, int recovery) {
        super(n, d, m, y, h, min, s, km);
        this.repetitions = repetitions;
        this.recovery = recovery;
    }

    /**
     * Retrieves the number of repetitions.
     * @return The number of repetitions.
     */
    public int getRepetitions() {
        return repetitions;
    }

    /**
     * Retrieves the duration of recovery.
     * @return The duration of recovery.
     */
    public int getRecovery() {
        return recovery;
    }

    /**
     * Generates a string representation of the sprint entry.
     * @return A string containing the details of the sprint entry.
     */
    @Override
    public String getEntry() {
        return getName() + " sprinted " + getDistance() + " km with " + repetitions + " repetitions and " + recovery + " seconds recovery in "
                + getHour() + ":" + getMin() + ":" + getSec() + " on " + getDay() + "/" + getMonth() + "/" + getYear() + "\n";
    }
}
