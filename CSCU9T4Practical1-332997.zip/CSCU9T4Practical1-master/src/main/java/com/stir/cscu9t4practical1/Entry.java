// This class holds information about a single training session
package com.stir.cscu9t4practical1;

import java.util.Calendar;
public class Entry {
  private String name;
  private Calendar dateAndTime;
  private float distance;
  private String terrain;
  private String tempo;

  /**
   * Constructs a new Entry with the provided details.
   * @param n The name of the entry.
   * @param d The day of the entry.
   * @param m The month of the entry.
   * @param y The year of the entry.
   * @param h The hour of the entry.
   * @param min The minute of the entry.
   * @param s The second of the entry.
   * @param dist The distance covered in the entry.
   */
  public Entry(String n, int d, int m, int y, int h, int min, int s, float dist) {
    name = n;
    Calendar inst = Calendar.getInstance();
    inst.set(y, m - 1, d, h, min, s);
    dateAndTime = inst;
    distance = dist;
    terrain = "";
    tempo = "";
  } //constructor

  public String getName() {
    return name;
  } //getName

  public int getDay() {
    return dateAndTime.get(Calendar.DATE);
  } //getDay

  public int getMonth() {
    int month = dateAndTime.get(Calendar.MONTH) + 1;
    return month;
  } //getMonth

  public int getYear() {
    return dateAndTime.get(Calendar.YEAR);
  } //getYear

  public int getHour() {
    return dateAndTime.get(Calendar.HOUR);
  } //getHour

  public int getMin() {
    return dateAndTime.get(Calendar.MINUTE);
  } //getMin

  public int getSec() {
    return dateAndTime.get(Calendar.SECOND);
  } //getSec

  public float getDistance() {
    return distance;
  } //getYear

  public String getTerrain() {
    return terrain;
  } // getTerrain

  public String getTempo() {
    return tempo;
  } // getTempo

  public String getWhere() {
    return "";
  } // getWhere

  /**
   * Retrieves the number of repetitions for the entry.
   * @return The number of repetitions.
   * @throws UnsupportedOperationException if this method is called on an Entry object.
   */
  public int getRepetitions() {
    throw new UnsupportedOperationException("This method is not supported for Entry objects");
  }

  /**
   * Retrieves the recovery time for the entry.
   * @return The recovery time.
   * @throws UnsupportedOperationException if this method is called on an Entry object.
   */
  public int getRecovery() {
    throw new UnsupportedOperationException("This method is not supported for Entry objects");
  }

  public String getEntry() {
    String result = getName() + " ran " + getDistance() + " km in " +
      getHour() + ":" + getMin() + ":" + getSec() + " on " +
      getDay() + "/" + getMonth() + "/" + getYear() + "\n";
    return result;
  } //getEntry

  public Entry(Calendar dateAndTime) {
    this.dateAndTime = dateAndTime;
  }
  public Calendar getDateAndTime() {
    return dateAndTime;
  }
} // Entry