// GUI and main program for the Training Record
package com.stir.cscu9t4practical1;

import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
import javax.swing.*;

public class TrainingRecordGUI extends JFrame implements ActionListener {

  private final JTextField name = new JTextField(20);
  private final JTextField day = new JTextField(2);
  private final JTextField month = new JTextField(2);
  private final JTextField year = new JTextField(4);
  private final JTextField hours = new JTextField(2);
  private final JTextField mins = new JTextField(2);
  private final JTextField secs = new JTextField(2);
  private final JTextField dist = new JTextField(4);
  private final JLabel labn = new JLabel("Name:");
  private final JLabel labd = new JLabel("Day:");
  private final JLabel labm = new JLabel("Month:");
  private final JLabel laby = new JLabel("Year:");
  private final JLabel labh = new JLabel("Hours:");
  private final JLabel labmm = new JLabel("Minutes:");
  private final JLabel labs = new JLabel("Seconds:");
  private final JLabel labdist = new JLabel("Distance (km):");
  private final JButton addR = new JButton("Add");
  private final JButton lookUpByDate = new JButton("Look Up");
  private final JButton removeR = new JButton("Remove");
  private final JButton findAllByDate = new JButton("Find All By Date");
  private final JButton findByName = new JButton("Find By Name");
  private final JTextField startDateField = new JTextField(10);
  private final JTextField endDateField = new JTextField(10);
  private TrainingRecord myAthletes = new TrainingRecord();
  private JTextArea outputArea = new JTextArea(5, 50);
  private final JLabel labStartDate = new JLabel("Start Date (DD/MM/YYYY):");
  private final JLabel labEndDate = new JLabel("End Date (DD/MM/YYYY):");
  public static void main(String[] args) {
    new TrainingRecordGUI();
  } // main

  // set up the GUI
  public TrainingRecordGUI() {
    super("Training Record");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout(10, 10)); // Adjusted spacing

    JPanel inputPanel = new JPanel(new GridLayout(10, 2, 10, 5)); // Increased rows and adjusted spacing
    JPanel buttonPanel = new JPanel(new GridLayout(1, 6, 10, 10));

    inputPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15)); // Adjusted border
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

    add(inputPanel, BorderLayout.NORTH);
    add(buttonPanel, BorderLayout.CENTER);

    // Wrap outputArea in a JScrollPane
    JScrollPane scrollPane = new JScrollPane(outputArea);
    add(scrollPane, BorderLayout.SOUTH);

    addRow(inputPanel, labn, name);
    addRow(inputPanel, labd, day);
    addRow(inputPanel, labm, month);
    addRow(inputPanel, laby, year);
    addRow(inputPanel, labh, hours);
    addRow(inputPanel, labmm, mins);
    addRow(inputPanel, labs, secs);
    addRow(inputPanel, labdist, dist);
    addRow(inputPanel, labStartDate, startDateField);
    addRow(inputPanel, labEndDate, endDateField);

    addButtons(buttonPanel);

    addR.addActionListener(this);
    lookUpByDate.addActionListener(this);
    removeR.addActionListener(this);
    findAllByDate.addActionListener(this);
    findByName.addActionListener(this);

    enableButtons(false);
    addR.setEnabled(true);

    outputArea.setEditable(false);

    pack();
    setLocationRelativeTo(null);
    setVisible(true);
  }

  // To save typing in new entries while testing, uncomment
  // the following lines (or add your own test cases)
  // constructor

  /**
   * Adds a row with label and text field to a given panel.
   * @param panel The panel to which the row is added.
   * @param label The label component.
   * @param textField The text field component.
   */
  private void addRow(JPanel panel, Component label, Component textField) {
    panel.add(label);
    panel.add(textField);
  }

  /**
   * Adds buttons to a given panel.
   * @param panel The panel to which buttons are added.
   */
  private void addButtons(JPanel panel) {
    panel.add(addR);
    panel.add(lookUpByDate);
    panel.add(removeR);
    panel.add(findAllByDate);
    panel.add(findByName);
  }

  /**
   * Enables or disables buttons based on the given boolean.
   * @param enable True to enable buttons, false to disable.
   */
  private void enableButtons(boolean enable) {
    lookUpByDate.setEnabled(enable);
    removeR.setEnabled(enable);
    findAllByDate.setEnabled(enable);
    findByName.setEnabled(enable);
  }

  /**
   * Responds to GUI events.
   * @param event The ActionEvent triggering the method.
   */
  @Override
  public void actionPerformed(ActionEvent event) {
    String message = "";
    if (event.getSource() == addR) {
      message = addEntry("generic");
    } else if (event.getSource() == lookUpByDate) {
      message = lookupEntry();
    } else if (event.getSource() == findAllByDate) {
      // Retrieve start and end dates from input fields
      String startDateInput = startDateField.getText();
      String endDateInput = endDateField.getText();

      String[] startDateParts = startDateInput.split("/");
      int startDay = Integer.parseInt(startDateParts[0]);
      int startMonth = Integer.parseInt(startDateParts[1]);
      int startYear = Integer.parseInt(startDateParts[2]);

      String[] endDateParts = endDateInput.split("/");
      int endDay = Integer.parseInt(endDateParts[0]);
      int endMonth = Integer.parseInt(endDateParts[1]);
      int endYear = Integer.parseInt(endDateParts[2]);

      message = findAllByDate(startDay, startMonth, startYear, endDay, endMonth, endYear);
    } else if (event.getSource() == findByName) {
      message = findEntriesByName();
    } else if (event.getSource() == removeR) {
      message = removeEntry();
    }
    outputArea.setText(message);
    blankDisplay();
  } // actionPerformed
  
  /**
   * Adds an entry to the TrainingRecord.
   * @param what The type of entry to add.
   * @return A message indicating the result of the operation.
   */
  public String addEntry(String what) {
    String message = "";
    try {
      int d = Integer.parseInt(day.getText());
      int m = Integer.parseInt(month.getText());
      int y = Integer.parseInt(year.getText());

      String n = name.getText().trim();
      if (n.isEmpty()) {
        throw new IllegalArgumentException("Name cannot be empty");
      }

      float km = java.lang.Float.parseFloat(dist.getText());
      int h = Integer.parseInt(hours.getText());
      int mm = Integer.parseInt(mins.getText());
      int s = Integer.parseInt(secs.getText());

      boolean isDuplicate = false;
      for (Entry entry: myAthletes.getEntryList()) {
        if (entry.getName().equals(n) && entry.getDay() == d && entry.getMonth() == m && entry.getYear() == y) {
          isDuplicate = true;
          break;
        }
      }

      if (isDuplicate) {
        throw new IllegalArgumentException("Duplicate entry");
      }
      Entry e = new Entry(n, d, m, y, h, mm, s, km);
      myAthletes.addEntry(e);
      message = "Record added";

      enableButtons(true);
    } catch (NumberFormatException e) {
      message = "Invalid input: Day, Month, Year, Hours, Minutes, and Seconds must be integers.";
    } catch (IllegalArgumentException e) {
      message = e.getMessage();
    }
    return message;
  }
  
  /**
   * Looks up an entry in the TrainingRecord.
   * @return A message containing the entry information or an error message.
   */
  public String lookupEntry() {
    try {
      int m = Integer.parseInt(month.getText());
      int d = Integer.parseInt(day.getText());
      int y = Integer.parseInt(year.getText());
      return myAthletes.lookupEntry(d, m, y);
    } catch (NumberFormatException e) {
      return "Invalid input: Day, Month, and Year .";
    }
  }
  
  /**
   * Finds all entries within a specified date range.
   * @param startDay The start day of the range.
   * @param startMonth The start month of the range.
   * @param startYear The start year of the range.
   * @param endDay The end day of the range.
   * @param endMonth The end month of the range.
   * @param endYear The end year of the range.
   * @return A message containing the entries within the date range or an error message.
   */
  public String findAllByDate(Integer startDay, Integer startMonth, Integer startYear, Integer endDay, Integer endMonth, Integer endYear) {
    try {
      String startDateInput = startDateField.getText();
      String endDateInput = endDateField.getText();

      String[] startDateParts = startDateInput.split("/");
      if (startDateParts.length != 3) {
        return "Invalid start date format. Please use DD/MM/YYYY format.";
      }

      String[] endDateParts = endDateInput.split("/");
      if (endDateParts.length != 3) {
        return "Invalid end date format. Please use DD/MM/YYYY format.";
      }

      int sDay = Integer.parseInt(startDateParts[0]);
      int sMonth = Integer.parseInt(startDateParts[1]);
      int sYear = Integer.parseInt(startDateParts[2]);
      int eDay = Integer.parseInt(endDateParts[0]);
      int eMonth = Integer.parseInt(endDateParts[1]);
      int eYear = Integer.parseInt(endDateParts[2]);

      if (sDay < 1 || sDay > 31 || sMonth < 1 || sMonth > 12 || sYear < 0 ||
        eDay < 1 || eDay > 31 || eMonth < 1 || eMonth > 12 || eYear < 0) {
        return "Please provide valid integer values for start and end dates.";
      }

      Calendar startDate = Calendar.getInstance();
      startDate.set(sYear, sMonth - 1, sDay);
      Calendar endDate = Calendar.getInstance();
      endDate.set(eYear, eMonth - 1, eDay);

      StringBuilder result = new StringBuilder("Entries between " + sDay + "/" + sMonth + "/" + sYear +
        " and " + eDay + "/" + eMonth + "/" + eYear + ":\n");

      boolean foundEntries = false;
      for (Entry entry: myAthletes.getEntryList()) {
          Calendar entryDate = entry.getDateAndTime();
          if (entryDate.compareTo(startDate) > 0 && entryDate.compareTo(endDate) < 0) {
              result.append(entry.getEntry()).append("\n");
              foundEntries = true;
          }
      }

      if (!foundEntries) {
        result.append("No entries found within the specified date range.");
      }

      return result.toString();
    } catch (NumberFormatException e) {
      return "Please provide valid integer values for start and end dates.";
    }
  }
  
  /**
   * Finds entries by name in the TrainingRecord.
   * @return A message containing the entries with the specified name or an error message.
   */
  public String findEntriesByName() {
    String nameToFind = name.getText().trim();
    if (nameToFind.isEmpty()) {
      return "Please enter a name";
    }

    boolean found = false;
    StringBuilder result = new StringBuilder("Entries for name '" + nameToFind + "':\n");
    for (Entry entry: myAthletes.getEntryList()) {
      if (entry.getName().equalsIgnoreCase(nameToFind)) {
        result.append(entry.toString()).append("\n");
        found = true;
      }
    }

    if (!found) {
      return nameToFind + " doesn't exist";
    }
    return result.toString();
  }
  
  /**
   * Removes an entry from the TrainingRecord.
   * @return A message indicating the result of the removal operation.
   */
  public String removeEntry() {
    String message = "";
    try {
      String n = name.getText().trim();
      int d = Integer.parseInt(day.getText());
      int m = Integer.parseInt(month.getText());
      int y = Integer.parseInt(year.getText());

      boolean isRemoved = myAthletes.removeEntry(n, d, m, y);
      if (isRemoved) {
        message = "Entry removed successfully";
      } else {
        message = "No matching entry found for removal";
      }
    } catch (NumberFormatException e) {
      message = "Invalid input: Name, Day, Month, or Year.";
    }
    return message;
  }

  public void blankDisplay() {
    name.setText("");
    day.setText("");
    month.setText("");
    year.setText("");
    hours.setText("");
    mins.setText("");
    secs.setText("");
    dist.setText("");

  } // blankDisplay
  
  /**
   * Fills input fields with data from a given Entry.
   * @param ent The Entry to display.
   */
  public void fillDisplay(Entry ent) {
    name.setText(ent.getName());
    day.setText(String.valueOf(ent.getDay()));
    month.setText(String.valueOf(ent.getMonth()));
    year.setText(String.valueOf(ent.getYear()));
    hours.setText(String.valueOf(ent.getHour()));
    mins.setText(String.valueOf(ent.getMin()));
    secs.setText(String.valueOf(ent.getSec()));
    dist.setText(String.valueOf(ent.getDistance()));
  }
} // TrainingRecordGUI